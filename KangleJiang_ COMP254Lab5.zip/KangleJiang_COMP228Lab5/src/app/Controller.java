/// author: Kangle Jiang
/// student#: 300952654
/// ojdbc & javafx 
package app;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Controller {

    private List<Player> players = new ArrayList<>();
    private Player selectedPlayer;
    private List<Game> games = new ArrayList<>();
    private List<PlayerAndGame> playerGames = new ArrayList<>();

    private Connection connection;
    private Statement statement;

    private void getPlayers() {
        try {
            ResultSet resultSet = statement.executeQuery("select * from player order by player_id");
            players.clear();
            while (resultSet.next()) {
                Player p = new Player(resultSet.getInt(1)
                        , resultSet.getString(2)
                        , resultSet.getString(3)
                        , resultSet.getString(4)
                        , resultSet.getString(5)
                        , resultSet.getString(6)
                        , resultSet.getString(7)
                );
                players.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void getgames() {
        try {
            ResultSet resultSet = statement.executeQuery("select * from game order by game_id");
            games.clear();
            while (resultSet.next()) {
                Game g = new Game(resultSet.getInt(1)
                        , resultSet.getString(2)
                );
                games.add(g);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void getPlayerGames() {
        try {
            ResultSet resultSet = statement.executeQuery("select pg.player_game_id,\n" +
                    "       pg.game_id,\n" +
                    "       pg.player_id,\n" +
                    "       pg.playing_date,\n" +
                    "       pg.score,\n" +
                    "       p.first_name,\n" +
                    "       p.last_name,\n" +
                    "       g.game_title from playerAndGame pg\n" +
                    "    join game g on pg.game_id = g.game_id\n" +
                    "    join player p on pg.player_id = p.player_id order by pg.player_game_id");
            playerGames.clear();
            while (resultSet.next()) {
                PlayerAndGame p = new PlayerAndGame(
                        resultSet.getInt(1)
                        , resultSet.getInt(2)
                        , resultSet.getInt(3)
                        , resultSet.getDate(4)
                        , resultSet.getString(5)
                        , resultSet.getString(6) + " " + resultSet.getString(7)
                        , resultSet.getString(8)
                );
                playerGames.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updatePlayerTableView() {
        ObservableList<Player> tableItems = FXCollections.observableArrayList(players);
        playerTableView.setItems(tableItems);
        playerTableView.refresh();
    }

    private void updateGameTableView() {
        ObservableList<Game> tableItems = FXCollections.observableArrayList(games);
        gameTableView.setItems(tableItems);
        gameTableView.refresh();
    }

    private void updatePlayerGameTableView() {
        ObservableList<PlayerAndGame> tableItems = FXCollections.observableArrayList(playerGames);
        playerAndGameTableView.setItems(tableItems);
        playerAndGameTableView.refresh();
    }


    
    /// initialize the tableviews
    @FXML
    public void initialize() {
        gameIdColumn.setCellValueFactory(new PropertyValueFactory<>("gameId"));
        gameTitleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));

        playerIdColumn.setCellValueFactory(new PropertyValueFactory<>("playerId"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        postalCodeColumn.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        provinceColumn.setCellValueFactory(new PropertyValueFactory<>("province"));
        phoneNumberColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));

        playerGameIdColumn.setCellValueFactory(new PropertyValueFactory<>("playerGameId"));
        playerColumn.setCellValueFactory(new PropertyValueFactory<>("playerName"));
        pgGameTitleColumn.setCellValueFactory(new PropertyValueFactory<>("gameTitle"));
        playingDateColumn.setCellValueFactory(new PropertyValueFactory<>("playingDate"));
        scoreColumn.setCellValueFactory(new PropertyValueFactory<>("score"));

        /// connect database drop tables if exist
        /// create tables insert some initial rows
        Runnable task = () -> {
//                        comp214_f19_ers_75
//                        password
//        jdbc:oracle:thin:@199.212.26.208:1521:sqld
//        jdbc:oracle:thin:@oracle1:1521:sqld
            try {
                connection = DriverManager.getConnection("jdbc:oracle:thin:@199.212.26.208:1521:sqld", "comp214_f19_ers_75", "password");
                statement = connection.createStatement();
                System.out.println("connected to database");


            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                statement.executeUpdate("drop table player cascade constraints");
                statement.executeUpdate("drop table game cascade constraints");
                statement.executeUpdate("drop table playerAndGame cascade constraints");
                statement.executeUpdate("drop sequence  game_seq");
                statement.executeUpdate("drop sequence  player_seq");
                statement.executeUpdate("drop sequence  playerAndGame_seq");
            } catch (Exception ex) {
                System.out.println("No need to drop tables;");
            }
            try{
                statement.executeUpdate("create table player(\n" +
                        "    player_id number(20) primary key ,\n" +
                        "    first_name varchar2(100),\n" +
                        "    last_name varchar2(10),\n" +
                        "    address varchar2(300),\n" +
                        "    postal_code varchar2(20),\n" +
                        "    province varchar2(10),\n" +
                        "    phone_number varchar2(20)\n" +
                        ")");
                statement.executeUpdate("create table game(\n" +
                        "    game_id number(20) primary key ,\n" +
                        "    game_title varchar(200)\n" +
                        ")");
                statement.executeUpdate("create table playerAndGame(\n" +
                        "    player_game_id number(20),\n" +
                        "    game_id number(20) references game (game_id),\n" +
                        "    player_id number(20) references player (player_id),\n" +
                        "    playing_date date,\n" +
                        "    score varchar2(20)\n" +
                        ")");
                statement.executeUpdate("CREATE SEQUENCE game_seq\n" +
                        " START WITH     1\n" +
                        " INCREMENT BY   1\n" +
                        " NOCACHE\n" +
                        " NOCYCLE");
                statement.executeUpdate("CREATE SEQUENCE player_seq\n" +
                        " START WITH     1\n" +
                        " INCREMENT BY   1\n" +
                        " NOCACHE\n" +
                        " NOCYCLE");
                statement.executeUpdate("CREATE SEQUENCE playerAndGame_seq\n" +
                        " START WITH     1\n" +
                        " INCREMENT BY   1\n" +
                        " NOCACHE\n" +
                        " NOCYCLE");
                statement.executeUpdate("insert into game values (game_seq.nextval, 'League Of Legends')");
                statement.executeUpdate("insert into game values (game_seq.nextval, 'Clash of Clan')");
                statement.executeUpdate("insert into game values (game_seq.nextval, 'Fortnite')");
                statement.executeUpdate("insert into game values (game_seq.nextval, 'MineCraft')");
                statement.executeUpdate("insert into game values (game_seq.nextval, 'Overwatch')");
                statement.executeUpdate("insert into game values (game_seq.nextval, 'Devil May Cry 5')");
                statement.executeUpdate("insert into game values (game_seq.nextval, ' Darksiders III')");

                statement.executeUpdate("insert into player values (player_seq.nextval, 'Kangle', 'Jiang', '31 Summerglade Dr', 'M1S 1W8', 'ON', '647-9498-370')");
                statement.executeUpdate("insert into player values (player_seq.nextval, 'Saguo', 'Ran', '31 Summerglade Dr', 'M1S 1W8', 'ON', '647-9498-370')");

                statement.executeUpdate("insert into playerAndGame values (playerAndGame_seq.nextval, 1, 1, '1-Dec-2019', 'Bronze')");
                statement.executeUpdate("insert into playerAndGame values (playerAndGame_seq.nextval, 2, 1, '1-Dec-2019', 'Champion')");
                statement.executeUpdate("insert into playerAndGame values (playerAndGame_seq.nextval, 3, 1, '1-Dec-2019', '99 Kills')");
            }catch (SQLException ex){
                ex.printStackTrace();
            }
            Platform.runLater(()->{
                getPlayers();
                getgames();
                getPlayerGames();
                updatePlayerTableView();
                updateGameTableView();
                updatePlayerGameTableView();
            });
        };
        new Thread(task).start();

        playerTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                selectedPlayer = newSelection;
                firstNameTextField.setText(selectedPlayer.getFirstName());
                lastNameTextField.setText(selectedPlayer.getLastName());
                addressTextArea.setText(selectedPlayer.getAddress());
                postalCodeTextField.setText(selectedPlayer.getPhoneNumber());
                provinceTextField.setText(selectedPlayer.getProvince());
                phoneNumberTextField.setText(selectedPlayer.getPhoneNumber());
            }
        });
    }

    /// define FXML controls
    @FXML
    private TableView<Game> gameTableView;

    @FXML
    private DatePicker datePicker;


    @FXML
    private TableView<PlayerAndGame> playerAndGameTableView;

    @FXML
    private TextField titleTextField;

    @FXML
    private TextField firstNameTextField;

    @FXML
    private TextField lastNameTextField;

    @FXML
    private TextField postalCodeTextField;

    @FXML
    private TextField provinceTextField;

    @FXML
    private TextField phoneNumberTextField;

    @FXML
    private TextArea addressTextArea;

    @FXML
    private TableColumn<Game, Integer> gameIdColumn;

    @FXML
    private TableColumn<Game, String> gameTitleColumn;

    @FXML
    private TableView<Player> playerTableView;

    @FXML
    private TableColumn<Player, String> playerIdColumn;

    @FXML
    private TableColumn<Player, String> firstNameColumn;

    @FXML
    private TableColumn<Player, String> lastNameColumn;

    @FXML
    private TableColumn<Player, String> addressColumn;

    @FXML
    private TableColumn<Player, String> postalCodeColumn;

    @FXML
    private TableColumn<Player, String> provinceColumn;

    @FXML
    private TableColumn<Player, String> phoneNumberColumn;

    @FXML
    private TableColumn<PlayerAndGame, Integer> playerGameIdColumn;

    @FXML
    private TableColumn<PlayerAndGame, String> playerColumn;

    @FXML
    private TableColumn<PlayerAndGame, String> pgGameTitleColumn;

    @FXML
    private TableColumn<PlayerAndGame, Date> playingDateColumn;

    @FXML
    private TableColumn<PlayerAndGame, String> scoreColumn;

    @FXML
    private TextField playerIdTextField;

    @FXML
    private TextField gameIdTextField;

    @FXML
    private TextField scoreTextField;

    @FXML
    private Label infoTextField;

    @FXML
    void onAddGame() {
        try {
            statement.executeUpdate(String.format("insert into game values (game_seq.nextval, '%s')", titleTextField.getText()));
            getgames();
            updateGameTableView();
            infoTextField.setText(String.format("%s is added to database", titleTextField.getText()));
        } catch (Exception e) {
            e.printStackTrace();
            infoTextField.setText(String.format("Failed to add %s to database", titleTextField.getText()));
        }

    }

    @FXML
    void onAddPlayerGame() {
        Runnable task = ()->{
            try {
                String pattern = "dd-MMM-yyyy";
                DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);

                statement.executeUpdate(String.format("insert into playerAndGame values (playerAndGame_seq.nextval, %d, %d, '%s', '%s')",
                        Integer.parseInt(gameIdTextField.getText()),
                        Integer.parseInt(playerIdTextField.getText()),
                        dateFormatter.format(datePicker.getValue()),
                        scoreTextField.getText())
                );
                getPlayerGames();
                updatePlayerGameTableView();
                infoTextField.setText(String.format("playerAndGame %s is added to database", gameIdTextField.getText()));
            } catch (Exception e) {
                e.printStackTrace();
                infoTextField.setText(String.format("failed to add playerAndGame %s to database", gameIdTextField.getText()));
            }
        };
        new Thread(task).start();

    }

    @FXML
    void onClear(ActionEvent event) {
        datePicker.getEditor().clear();
        titleTextField.clear();
        firstNameTextField.clear();
        lastNameTextField.clear();
        postalCodeTextField.clear();
        provinceTextField.clear();
        phoneNumberTextField.clear();
        addressTextArea.clear();
        playerIdTextField.clear();
        gameIdTextField.clear();
        scoreTextField.clear();
        infoTextField.setText("");
    }


    @FXML
    void onAddPlayer(ActionEvent event) {
        try {
            statement.executeUpdate(String.format("insert into player values (player_seq.nextval, '%s', '%s', '%s', '%s', '%s', '%s')",
                    firstNameTextField.getText(),
                    lastNameTextField.getText(),
                    addressTextArea.getText(),
                    postalCodeTextField.getText(),
                    provinceTextField.getText(),
                    phoneNumberTextField.getText()
                    )
            );
            getPlayers();
            updatePlayerTableView();
            infoTextField.setText(String.format("Player %s is added to database", firstNameTextField.getText()));
        } catch (Exception e) {
            e.printStackTrace();
            infoTextField.setText(String.format("failed to added Player %s to database", firstNameTextField.getText()));
        }
    }

    @FXML
    void onSavePlayer() {
        try {
            statement.executeUpdate(String.format("update player set first_name = '%s', last_name = '%s', address = '%s', postal_code = '%s', province = '%s', phone_number = '%s' where player_id = %d",
                    firstNameTextField.getText(),
                    lastNameTextField.getText(),
                    addressTextArea.getText(),
                    postalCodeTextField.getText(),
                    provinceTextField.getText(),
                    phoneNumberTextField.getText(),
                    selectedPlayer.getPlayerId()
                    )
            );
            getPlayers();
            updatePlayerTableView();
            infoTextField.setText(String.format("Player %s is updated to database", firstNameTextField.getText()));
        } catch (Exception e) {
            e.printStackTrace();
            infoTextField.setText(String.format("Player %s is updated to database", firstNameTextField.getText()));
        }
    }

}
