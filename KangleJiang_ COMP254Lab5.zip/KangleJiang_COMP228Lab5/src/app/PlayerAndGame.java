package app;

import java.sql.Date;

public class PlayerAndGame {

    private int playerGameId;
    private int gameId;
    private int playerId;
    private Game game;
    private Player player;
    private Date playingDate;
    private String Score;
    private String playerName;
    private String gameTitle;

    public PlayerAndGame(int playerAndGameId, int gameId, int playerId, Date playingDate, String score, String playerName, String gameTitle) {
        this.playerGameId = playerAndGameId;
        this.gameId = gameId;
        this.playerId = playerId;
        this.playingDate = playingDate;
        Score = score;
        this.playerName = playerName;
        this.gameTitle = gameTitle;
    }


    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getGameTitle() {
        return gameTitle;
    }

    public void setGameTitle(String gameTitle) {
        this.gameTitle = gameTitle;
    }

    public int getPlayerGameId() {
        return playerGameId;
    }

    public void setPlayerGameId(int playerGameId) {
        this.playerGameId = playerGameId;
    }

    public int getGameId() {
        return gameId;
    }

    public void setGameId(int gameId) {
        this.gameId = gameId;
    }

    public int getPlayerId() {
        return playerId;
    }

    public void setPlayerId(int playerId) {
        this.playerId = playerId;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public Date getPlayingDate() {
        return playingDate;
    }

    public void setPlayingDate(Date playingDate) {
        this.playingDate = playingDate;
    }

    public String getScore() {
        return Score;
    }

    public void setScore(String score) {
        Score = score;
    }
}
